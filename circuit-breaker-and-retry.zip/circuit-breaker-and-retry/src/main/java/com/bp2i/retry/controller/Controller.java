package com.bp2i.retry.controller;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeoutException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bp2i.retry.service.RetryService;
import com.bp2i.retry.service.Service;

@RestController
public class Controller {

    @Autowired
    private Service service;
    @Autowired
    private RetryService retryService;

    @GetMapping("/")
    public String getValues() {
        return service.fetchData();
    }

    @GetMapping("/api")
    public String callApi() {
        return service.callApi();
    }

    @GetMapping("/sleep")
    public CompletableFuture<String> callApiWithDelay() throws TimeoutException {
        return CompletableFuture.supplyAsync(service::callApiWithDelay);
    }

    @GetMapping("/retry")
    public String getRetryValues() {
        return retryService.fetchData();
    }
}
