package com.bp2i.retry.exception;

public class IgnoreException extends Exception {
}
