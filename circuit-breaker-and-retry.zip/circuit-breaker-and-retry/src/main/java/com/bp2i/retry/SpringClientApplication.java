package com.bp2i.retry;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.bp2i.retry.service.Service;

@SpringBootApplication
public class SpringClientApplication {

    @Autowired
    Service service;

    public static void main(String[] args) {
        SpringApplication.run(SpringClientApplication.class, args);
    }

}
