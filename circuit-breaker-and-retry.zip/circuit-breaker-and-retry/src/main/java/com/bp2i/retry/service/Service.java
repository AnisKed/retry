package com.bp2i.retry.service;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;
import io.github.resilience4j.timelimiter.annotation.TimeLimiter;
import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDateTime;
import java.util.concurrent.CompletableFuture;

@org.springframework.stereotype.Service

@Slf4j
public class Service {

    @Value("${service2.url:http://localhost:6060/service2}")
    String serviceUrl;

    @Value("https://api.publicapis.org/entries")
    String serviceApi;

    @CircuitBreaker(name = "myCircuitBreaker", fallbackMethod = "fallback")
    @Retry(name = "myRetry")
    public String fetchData() {
        log.info("Inside get service api.");
        log.info(" Making a request to " + serviceUrl + " at :" + LocalDateTime.now());
        RestTemplate restTemplate = new RestTemplate();
        return restTemplate.getForObject(serviceUrl, String.class);
    }

    public String fallback(Exception e) {
        log.info("Inside fallback api:" + e.getMessage());
        return "fallback value";
    }

    public String timelimitFallback(Exception e) {
        log.info("timelimitFallback:" + e.getMessage());
        return "timelimitFallback";
    }

    @CircuitBreaker(name = "myCircuitBreaker", fallbackMethod = "timelimitFallback")
    @TimeLimiter(name = "timeLimiterApi")
    public CompletableFuture<String> timeLimiterApi() {
        log.info("call Api with delay");
        return CompletableFuture.supplyAsync(this::callApiWithDelay);
    }

    @CircuitBreaker(name = "myCircuitBreaker", fallbackMethod = "timelimitFallback")
    @TimeLimiter(name = "timeLimiterApi")
    public String callApiWithDelay() {
        log.info("slowMethod going to sleep for 5 seconds...");
        RestTemplate restTemplate = new RestTemplate();
        String result = restTemplate.getForObject(serviceApi, String.class);
        try {
            Thread.sleep(5000);
        } catch (InterruptedException ignore) {
        }
        return result;
    }

    public String callApi() {
        log.info("call Api");
        return "API Working";
    }
}
